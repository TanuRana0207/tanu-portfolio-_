// Portfolio website JavaScript

console.log("Portfolio website loaded successfully.");
